# 授信客戶具利關人報表_利關人異動查詢API

> **重要提醒：本文件為API規格文件撰寫範本**
>
> **個資遮罩原則：**
> - 身分證號：保留開頭1碼和結尾3碼，中間以***** 遮罩（如：A123*****789）
> - 姓名：中文姓名以***** 表示，英文姓名保留首字母和部分字母，中間以***** 遮罩
> - 地址：保留縣市和區域，詳細地址以**** 遮罩
> - 電話：保留區碼和部分號碼，核心號碼以***** 遮罩（如：02-1*****5678）
> - Email：保留網域部分，帳號部分以***** 遮罩（如：test@ex*****le.com）
> - 帳號：核心數字以*****遮罩

---

## 版本資訊
| 版號 | 日期 | 異動摘要 | 修訂人員 |
| --- | --- | --- | --- |
| 1.0 | 2026/11/27 | 初版 | 李桂昇 |

## PaaS Domain
| PaaS Domain | 說明 |
| --- | --- |
| http://com-oca-query-rs.apps.paas-sit.ocpt.cathaysec.com.tw | 測試環境，沒走Kong |
| https://api-sit-nh.intra-sit.cathaysec.com.tw/com-oca-query-rs | 系統整合測試環境 |
| https://api-uat-nh.intra-uat.cathaysec.com.tw/com-oca-query-rs | 使用者驗收測試環境 |
| https://api-nh.intra-prd.cathaysec.com.tw/com-oca-query-rs | 正式環境 |

## Swagger 參考文件
參考： http://com-oca-query-rs.apps.paas-sit.ocpt.cathaysec.com.tw/swagger/index.html

---

## API名稱：授信利關人異動查詢

**API路徑：**[Paas Domain](#paas-domain)/OCAWeb/IASQRY075Query

### 說明
本功能提供授信客戶具利害關係人異動報表(畫面編號IASQRY076)之資料查詢服務。外部系統透過 API 發送查詢請求，系統接收 Request 後，依據Request的「分公司」、「身分證號/統一編號」、「客戶姓名」、「異動類型」與「查詢日期」區間，查詢授信客戶資料(CreditCusData)中有效戶(Status='3')之利害關係人異動名單：

- 歷史：利關人(IS44='Y')且最後比對日期早於查詢日期(起)，並且該帳號總授信額度大於等於1億。
- 新增：利關人(IS44='Y')且最後比對日期介於查詢日期區間，貼標處理為「新增貼標」。
- 刪除：移除利關人(IS44='N')且最後比對日期介於查詢日期區間，總授信額度回0(報表顯示空白)，貼標處理為「移除貼標」。

總授信額度為同分公司、同帳號之利關人有效戶授信額度加總，大於等於1億者「是否須提報董事會」為「須提報董事會」，否則為「否」。異動類型為「全部」時回傳歷史、新增、刪除三類資料，同一帳號可能出現於不同類型。查詢結果依 Response 封裝為 JSON 格式回傳予呼叫端，由前端產製PDF報表。

### 輸入參數 (Header)
| 名稱 | 格式 | 說明 | 屬性 | 範例 | 備註 |
| --- | --- | --- | --- | --- | --- |
| **Token** | string | 連線驗證 | Req. |  |  |
| **UserId** | string | 使用者 | Req. |  |  |
| **SourceChannel** | string | 來源通道 | Req. |  | 追蹤用 |
| **MessageID** | string | 訊息代碼 | Req. | XXX-00000001 | 自編(交易日需唯一) |

### Body
| 名稱 | 格式 | 說明 | 屬性 | 範例 | 備註 |
| --- | --- | --- | --- | --- | --- |
| IdNo | string | 身分證號/統一編號 | Opt. | A123*****789 | 最長10碼，限英數字；空值表示不篩選 |
| **BranchId** | string | 分公司代號 | Req. | 8880 | 4碼 |
| CustName | string | 客戶姓名/名稱 | Opt. | 林 | 最長50字，模糊查詢；空值表示不篩選 |
| ***ChangeType*** | string | 異動類型 | Req. | 1 | 1：全部、2：歷史、3：新增、4：刪除 |
| **StartDate** | string | 查詢日期(起) | Req. | 20261101 | yyyyMMdd；不可大於查詢日期(迄) |
| **EndDate** | string | 查詢日期(迄) | Req. | 20261127 | yyyyMMdd；與查詢日期(起)區間不可超過6個月 |

### 輸出參數 Response
| 名稱 | 格式 | 說明 | 範例 | 備註 |
| --- | --- | --- | --- | --- |
| MsgId | string | TraceId | bd76582f1c9133693db8549553c69383 |  |
| Code | string | 執行結果代碼 | 000000 | 非000000為異常回覆 |
| Msg | string | 執行結果說明 | 處理成功 |  |
| Timestamp | string | 主機時戳 | 20261127104730561 | yyyyMMddHHmmssSSS |
| TimeElapsed | string | 主機耗時 | 5 | milliseconds |
| Data | Array | 第一層JSON Array[0..n] |  | 查無資料時為空陣列 |

### Data 欄位
| 名稱 | 格式 | 說明 | 範例 | 備註 |
| --- | --- | --- | --- | --- |
| *ChangeType* | string | 異動類型代碼 | 2 | 2：歷史、3：新增、4：刪除 |
| *ChangeTypeName* | string | 異動類型名稱 | 歷史 | 歷史、新增、刪除 |
| Account | string | 客戶帳號 | 01*****56 |  |
| CustName | string | 客戶姓名/名稱 | 蔡O |  |
| TotalCreditAmt | decimal | 總授信額度 | 100000000 | 刪除類型固定回0，報表顯示空白 |
| *ReportToBoard* | string | 是否須提報董事會 | 須提報董事會 | 總授信額度>=1億為「須提報董事會」，否則為「否」 |
| *TagAction* | string | 貼標處理 |  | 歷史：空白、新增：新增貼標、刪除：移除貼標 |

---
### 範例 JSON (Request)
```json
{
  "Header": {
    "Token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "UserId": "USER001",
    "SourceChannel": "WEB",
    "MessageID": "XXX-00000001"
  },
  "Body": {
    "IdNo": "",
    "BranchId": "8880",
    "CustName": "",
    "ChangeType": "1",
    "StartDate": "20261101",
    "EndDate": "20261127"
  }
}
```

### 範例 JSON (Response - 成功)
```json
{
  "MsgId": "bd76582f1c9133693db8549553c69383",
  "Code": "000000",
  "Msg": "處理成功",
  "Timestamp": "20261127104730561",
  "TimeElapsed": "5",
  "Data": [
    {
      "ChangeType": "2",
      "ChangeTypeName": "歷史",
      "Account": "01*****56",
      "CustName": "蔡O",
      "TotalCreditAmt": 100000000,
      "ReportToBoard": "須提報董事會",
      "TagAction": ""
    },
    {
      "ChangeType": "3",
      "ChangeTypeName": "新增",
      "Account": "12*****67",
      "CustName": "林O",
      "TotalCreditAmt": 120000000,
      "ReportToBoard": "須提報董事會",
      "TagAction": "新增貼標"
    },
    {
      "ChangeType": "4",
      "ChangeTypeName": "刪除",
      "Account": "34*****89",
      "CustName": "陳O",
      "TotalCreditAmt": 0,
      "ReportToBoard": "否",
      "TagAction": "移除貼標"
    }
  ]
}
```

### 範例 JSON (Response - 失敗)
```json
{
  "MsgId": "bd76582f1c9133693db8549553c69383",
  "Code": "999999",
  "Msg": "系統錯誤：資料庫連線失敗",
  "Timestamp": "20261127104730561",
  "TimeElapsed": "5",
  "Data": null
}
```
---
### 邏輯
```sql
--輸入參數
DECLARE @IdNo AS VARCHAR(10)= '';
DECLARE @BranchId AS VARCHAR(4)= '8880';
DECLARE @CustName AS NVARCHAR(50)= '';
DECLARE @ChangeType AS VARCHAR(1)= '1';
DECLARE @StartDate AS VARCHAR(8)= '20261101';
DECLARE @EndDate AS VARCHAR(8)= '20261127';

DECLARE @SDate AS DATE = CONVERT(DATE, @StartDate, 112);
DECLARE @EDate AS DATE = CONVERT(DATE, @EndDate, 112);

--總授信額度：利關人(IS44='Y') + 有效戶(Status='3')，依分公司+帳號加總
WITH Total AS (
    SELECT BranchId, Account, SUM(CreditAmt) AS TotalCreditAmt
    FROM [dbo].[CreditCusData]
    WHERE BranchId = @BranchId AND IS44 = 'Y' AND Status = '3'
    GROUP BY BranchId, Account
),
--異動名單：2歷史、3新增、4刪除
Src AS (
    SELECT '2' AS ChangeType, BranchId, Account, MAX(IDNO) AS IDNO
    FROM [dbo].[CreditCusData]
    WHERE BranchId = @BranchId AND IS44 = 'Y' AND Status = '3'
      AND CONVERT(DATE, LastMatchingDate) < @SDate
    GROUP BY BranchId, Account
    UNION ALL
    SELECT '3', BranchId, Account, MAX(IDNO)
    FROM [dbo].[CreditCusData]
    WHERE BranchId = @BranchId AND IS44 = 'Y' AND Status = '3'
      AND CONVERT(DATE, LastMatchingDate) BETWEEN @SDate AND @EDate
    GROUP BY BranchId, Account
    UNION ALL
    SELECT '4', BranchId, Account, MAX(IDNO)
    FROM [dbo].[CreditCusData]
    WHERE BranchId = @BranchId AND IS44 = 'N' AND Status = '3'
      AND CONVERT(DATE, LastMatchingDate) BETWEEN @SDate AND @EDate
    GROUP BY BranchId, Account
)
SELECT s.ChangeType,
       CASE s.ChangeType WHEN '2' THEN N'歷史' WHEN '3' THEN N'新增' WHEN '4' THEN N'刪除' END AS ChangeTypeName,
       RTRIM(s.Account) AS Account,
       RTRIM(c.CustName) AS CustName,
       CASE WHEN s.ChangeType = '4' THEN 0 ELSE ISNULL(t.TotalCreditAmt, 0) END AS TotalCreditAmt,
       CASE WHEN s.ChangeType <> '4' AND t.TotalCreditAmt >= 100000000 THEN N'須提報董事會' ELSE N'否' END AS ReportToBoard,
       CASE s.ChangeType WHEN '3' THEN N'新增貼標' WHEN '4' THEN N'移除貼標' ELSE '' END AS TagAction
FROM Src s
LEFT JOIN Total t ON t.BranchId = s.BranchId AND t.Account = s.Account
LEFT JOIN [dbo].[StkCusData] c ON c.BranchId = s.BranchId AND c.Account = s.Account AND c.IDNO = s.IDNO
WHERE (@ChangeType = '1' OR s.ChangeType = @ChangeType)
  AND (s.ChangeType <> '2' OR t.TotalCreditAmt >= 100000000)   --歷史僅列總授信額度>=1億
  AND (@IdNo = '' OR s.IDNO = @IdNo)
  AND (@CustName = '' OR c.CustName LIKE '%' + @CustName + '%')
ORDER BY s.ChangeType, s.Account;
```

---

## 錯誤代碼說明
| 代碼 | 說明 | 處理方式 |
|------|--------|----------|
| 000000 | 處理成功 | - |
| 400001 | 無效的模型狀況 | 查無符合條件的資料 |
| 404001 | 未找到資料 | 請確認查詢條件是否正確 |
| 900000 | SQL執行例外狀況 | SQL執行例外狀況  |
| 901000 | 參數驗證失敗 | 請檢查必填欄位是否完整，查詢日期(起)不可大於查詢日期(迄)且區間不可超過6個月 |
| 999999 | 不明或未定義的錯誤 | 發生未預期錯誤，請聯繫系統管理員 |

---

## 變更紀錄
| 日期 | 版本 | 變更內容 | 負責人 |
| --- | --- | --- | --- |
| 2026/11/27 | 1.0 | 初版 | 李桂昇 |
