# 線上授信審件_徵審表資料查詢API

> **重要提醒：本文件為API規格文件撰寫範本**
> 
> **個資遮罩原則：**
> - 身分證號：保留開頭1碼和結尾3碼，中間以***** 遮罩（如：A*****789）
> - 姓名：中文姓名以O遮罩（如：林O哲），英文姓名保留首字母和部分字母，中間以***** 遮罩
> - 地址：保留縣市和區域，詳細地址以**** 遮罩
> - 電話：保留區碼和部分號碼，核心號碼以***** 遮罩（如：02-1*****5678）
> - Email：保留網域部分，帳號部分以***** 遮罩（如：test@ex*****le.com）
> - 帳號：核心數字以*****遮罩

---

## 版本資訊
| 版號 | 日期 | 異動摘要 | 修訂人員 |
| --- | --- | --- | --- |
| 1.0 | 2026/11/17 | 初版 | 李桂昇 |
| 1.1 | 2026/11/18 | 新增契約開戶日由R6DB取得時回寫PC_OLAccount | 李桂昇 |
| 1.2 | 2026/11/18 | 補充sp_GetB27Data回傳結構與筆數規則，新增錯誤碼404002 | 李桂昇 |

## PaaS Domain
| PaaS Domain | 說明 |
| --- | --- |
| http://com-oca-query-rs.apps.paas-sit.ocpt.cathaysec.com.tw | 測試環境，沒走Kong |
| https://api-sit-nh.intra-sit.cathaysec.com.tw/com-oca-query-rs | 系統整合測試環境 |
| https://api-uat-nh.intra-uat.cathaysec.com.tw/com-oca-query-rs | 使用者驗收測試環境 |
| https://api-nh.intra-prd.cathaysec.com.tw/com-oca-query-rs | 正式環境 |

## Swagger 參考文件
參考： http://com-oca-query-rs.apps.paas-sit.ocpt.cathaysec.com.tw/swagger/index.html

---

## API名稱：徵審表資料查詢

**API路徑：**[Paas Domain](#paas-domain)/CreditAccount/GetCreditReviewForm

### 說明
本功能提供「授信業務額度與徵信審核表」（徵審表）報表所需資料的查詢服務。外部系統透過 API 發送查詢請求，系統接收 Request 後，依據 Request 的「線上授信申請序號」、「證券分公司代號」、「證券帳號」，查詢該筆線上授信申請的主檔（PC_OLAccount）、RPA 資料（PC_RPA）、歸戶檔（AcctInfoByID）、營業員徵信資料（PC_CreditInfoBySales，含財力資料）、CRM 聯徵 B27 資料、高風險說明、關聯戶額度與契約開戶日，並依徵審表規則計算投資經驗、交易頻率、開戶滿三個月、申請額度、總授信額度及核准日／開戶日／有效日，將結果依 Response 封裝為 JSON 格式回傳予呼叫端，由呼叫端填入報表。

- 回傳內容為原始值與判斷結果代碼，報表的勾選框與文字由呼叫端依代碼組成。
- 本 API 沿用現行報表的回寫行為：申請種類不是新開(1)或續約(3)，PC_OLAccount 查不到契約開戶日，改由 R6DB 查到時，將契約開戶日回寫 PC_OLAccount.ContractOpenDate（ModifiedUser 為 Header.UserId），規則見邏輯5c。其他情況不異動任何資料表。
- 回寫失敗時整支 API 回覆 900000，Data 為 null，不回傳查詢結果。
- 歸戶檔 AcctInfoByID 以 inner join 取 Type='1' 的資料，該帳號無歸戶資料時視同查無資料，回覆 404001。
- 申請日（PC_OLAccount.ApplyDate）為空時，僅略過調整額度的契約開戶日查詢與回寫（ContractOpenDate 為空字串），其他欄位照常計算回傳，規則見邏輯6.0。
- 聯徵 B27 已送查詢但結果尚未回覆時（sp_GetB27Data 回傳結構B），回覆 404002，Data 為 null，呼叫端提示使用者稍後再查詢。規則見邏輯6.7。

### 輸入參數 (Header)
| 名稱 | 格式 | 說明 | 屬性 | 範例 | 備註 |
| --- | --- | --- | --- | --- | --- |
| **Token** | string | 連線驗證 | Req. |  |  |
| **UserId** | string | 使用者 | Req. |  | 回寫契約開戶日時作為ModifiedUser |
| **SourceChannel** | string | 來源通道 | Req. |  | 追蹤用 |
| **MessageID** | string | 訊息代碼 | Req. | XXX-00000001 | 自編(交易日需唯一) |

### Body
| 名稱 | 格式 | 說明 | 屬性 | 範例 | 備註 |
| --- | --- | --- | --- | --- | --- |
| **SeqNo** | string | 線上授信申請序號 | Req. | 00012345 | 8碼，對應PC_OLAccount.SeqNo、PC_CreditInfoBySales.OnlineSeqNo |
| **BranchId** | string | 證券分公司代號 | Req. | 888V | 4碼 |
| **Account** | string | 證券帳號 | Req. | 9*****3 | 7碼(含檢核碼) |

### 輸出參數 Response
| 名稱 | 格式 | 說明 | 範例 | 備註 |
| --- | --- | --- | --- | --- |
| MsgId | string | TraceId | bd76582f1c9133693db8549553c69383 |  |
| Code | string | 執行結果代碼 | 000000 | 非000000為異常回覆 |
| Msg | string | 執行結果說明 | 處理成功 |  |
| Timestamp | string | 主機時戳 | 20261117104730561 | yyyyMMddHHmmssSSS |
| TimeElapsed | string | 主機耗時 | 35 | milliseconds |
| Data | Object | 第一層JSON Object |  | 單筆；查無資料時為null並回覆404001；聯徵結果尚未回覆時為null並回覆404002 |

### Data 欄位
| 名稱 | 格式 | 說明 | 範例 | 備註 |
| --- | --- | --- | --- | --- |
| SeqNo | string | 線上授信申請序號 | 00012345 |  |
| BranchId | string | 證券分公司代號 | 888V |  |
| Account | string | 證券帳號 | 9*****3 | 含檢核碼 |
| IDNO | string | 身分證字號 | A*****789 | PC_OLAccount.IDNO |
| CustName | string | 客戶姓名 | 林O哲 | StkCusData.CustName |
| *Status* | string | 申請狀態 | 3 | 3:已完成；PC_OLAccount.Status |
| *Kind* | string | 申請項目代碼 | 1 | 1:信用 2:款項借貸 3:有價證券借貸 4:不限用途款項借貸 |
| KindDes | string | 申請項目名稱 | 信用 | Content(ItemName='CreditActKind') |
| *Type* | string | 申請種類代碼 | 1 | 1:新開 2:調整額度(變更) 3:續約 |
| TypeDes | string | 申請種類名稱 | 新開 | Content(ItemName='ApplyCreditActType') |
| FinishDate | string | 作業完成日 | 20261105 | yyyyMMdd；PC_OLAccount.OpenDate，未完成為空字串 |
| ApplyDate | string | 申請日(報表) | 20261105 | yyyyMMdd；同FinishDate |
| SignDate | string | 簽約日 | 20261105 | yyyyMMdd；同FinishDate |
| AllowDate | string | 核准日 | 20261105 | yyyyMMdd；規則見邏輯6.5 |
| OpenDate | string | 開戶日 | 20261105 | yyyyMMdd；規則見邏輯6.5 |
| EffectDate | string | 有效日 | 20291104 | yyyyMMdd；規則見邏輯6.5，借券為空字串 |
| ContractOpenDate | string | 契約開戶日 | 20261105 | yyyyMMdd；規則見邏輯5 |
| *Refund* | string | 退票記錄 | N | Y:是 N:否 空字串:不適用 |
| AccountODate | string | 證券帳戶開戶日 | 20180312 | yyyyMMdd；AcctInfoByID.ODate |
| *StkOpenMonthFlag* | string | 開設受託買賣帳戶滿三個月 | Y | Y:是 N:否；規則見邏輯6.1 |
| InvestExpDays | number | 投資經驗天數 | 3156 | 證券開戶日至PC_RPA異動日天數；無PC_RPA資料為null |
| *InvestExpCode* | string | 投資經驗 | 5 | 1:新開戶 2:1年以下 3:1年至2年 4:2年至5年 5:5年以上；無PC_RPA資料為null |
| TradeCount | number | 交易次數 | 45 | PC_RPA.TradeCount；無資料為null |
| *TradeFreqCode* | string | 交易頻率 | 2 | 1:每日 2:每週 3:每季 4:半年 5:一年以上 |
| *CType4Flag* | string | 聯合徵信記錄 | 0 | 0:正常 其他:異常 空字串:未填 |
| CType4Des | string | 聯合徵信異常說明 |  | PC_CreditInfoBySales.CType_4_Des |
| *BreakFlag* | string | 違約記錄 | N | Y:是 其他:否 空字串:無B27資料；sp_GetB27Data.BREAK；規則見邏輯6.7 |
| B27QryDate | string | 聯徵查詢日期 | 20261028 | yyyyMMdd；sp_GetB27Data.QryDate；無資料為空字串；規則見邏輯6.7 |
| CreditOpenCnt | number | 已開信用戶數 | 1 | sp_GetB27Data.CREDIT_OPEN；無資料為0；規則見邏輯6.7 |
| NlbOpenCnt | number | 已開證券借貸戶數 | 0 | sp_GetB27Data.NLB_OPEN；無資料為0；規則見邏輯6.7 |
| AdvOpenCnt | number | 已開借貸款項戶數 | 0 | sp_GetB27Data.ADV_OPEN；無資料為0；規則見邏輯6.7 |
| AnyOpenCnt | number | 已開不限用途款項借貸戶數 | 0 | sp_GetB27Data.ANY_OPEN；無資料為0；規則見邏輯6.7 |
| NlbAmount | number | 證券借貸借券餘額(千元) | 0 | sp_GetB27Data.NLB_AMOUNT；無資料為0；規則見邏輯6.7 |
| B27AbnormalNote | string | 聯徵異常說明 | null | 僅HighRiskAccountTag='Y'時有值，否則null |
| AmountNote | string | 高風險說明 | null | 僅HighRiskAccountTag='Y'時有值，否則null |
| TradeAmt | number | 交易量 | 1250.5 | PC_RPA.TradeAmt；無資料為null |
| InventoryAmt | number | 庫存 | 860 | PC_RPA.InventoryAmt；無資料為null |
| ExpectAmt | number | 本次申請額度(萬元) | 300 | PC_OLAccount.ExpectAmt；null為0 |
| Credit | number | 本人現有信用額度(萬元) | 0 | PC_RPA.Credit；null為0 |
| MoneyLending | number | 本人現有借貸款項額度(萬元) | 100 | PC_RPA.MoneyLending；null為0 |
| SecurityLending | number | 本人現有有價證券借貸額度(萬元) | 0 | PC_RPA.SecurityLending；null為0 |
| OpenEnded | number | 本人現有不限用途款項借貸額度(萬元) | 50 | PC_RPA.OpenEnded；null為0 |
| ApplyCredit | number | 申請信用額度(融資/融券)(萬元) | 300 | Kind=1時為ExpectAmt，否則0 |
| ApplyMoneyLending | number | 申請借貸款項額度(萬元) | 0 | Kind=2時為ExpectAmt，否則0 |
| ApplySecurityLending | number | 申請有價證券借貸額度(萬元) | 0 | Kind=3時為ExpectAmt，否則0 |
| ApplyOpenEnded | number | 申請不限用途款項借貸額度(萬元) | 0 | Kind=4時為ExpectAmt，否則0 |
| CreditR | number | 關聯戶信用額度(萬元) | 200 | PC_RPA.CreditR+AffCreditR；規則見邏輯6.4 |
| MoneyLendingR | number | 關聯戶借貸款項額度(萬元) | 0 | PC_RPA.MoneyLendingR+AffMoneyLendingR；規則見邏輯6.4 |
| SecurityLendingR | number | 關聯戶有價證券借貸額度(萬元) | 0 | PC_RPA.SecurityLendingR+AffSecurityLendingR；規則見邏輯6.4 |
| OpenEndedR | number | 關聯戶不限用途款項借貸額度(萬元) | 0 | PC_RPA.OpenEndedR+AffOpenEndedR；規則見邏輯6.4 |
| TotalLimit | number | 總授信額度-本人(萬元) | 450 | 規則見邏輯6.4 |
| TotalLimitR | number | 總授信額度-含關聯戶(萬元) | 650 | 規則見邏輯6.4 |
| SalesName | string | 營業員姓名 | 陳O宏 | ApplySalesName優先，否則fn_GetEmpName(SalesNo) |
| SalesADate | string | 營業員簽核日期 | 20261103 | yyyyMMdd；Sales_ADate，未簽核為空字串 |
| DBossName | string | 部室主管/經理人姓名 | 王O明 | fn_GetEmpName(DBossNo) |
| DBossADate | string | 部室主管/經理人簽核日期 | 20261103 | yyyyMMdd；DBoss_ADate，未簽核為空字串 |
| SupervisorName | string | 督導姓名 | 張O華 | fn_GetEmpName(SupervisorNo) |
| SupervisorADate | string | 督導簽核日期 | 20261104 | yyyyMMdd；Supervisor_ADate，未簽核為空字串 |
| DirectName | string | 處長姓名 |  | fn_GetEmpName(DirectNo) |
| DirectADate | string | 處長簽核日期 |  | yyyyMMdd；Direct_ADate，未簽核為空字串 |
| GMBossName | string | 總經理姓名 |  | fn_GetEmpName(GMBossNo) |
| GMBossADate | string | 總經理簽核日期 |  | yyyyMMdd；GMBoss_ADate，未簽核為空字串 |
| BackOfficerName | string | 後台經辦姓名 | 李O君 | 查無員工時取代理人(Content SubstituteBK) |
| BackOfficerADate | string | 後台經辦簽核日期 | 20261105 | yyyyMMdd；BackOfficer_ADate，未簽核為空字串 |
| BEBossName | string | 後台主管姓名 | 黃O德 | 查無員工時取代理人(Content Substitute) |
| BEBossADate | string | 後台主管簽核日期 | 20261105 | yyyyMMdd；BEBoss_ADate，未簽核為空字串 |
| BankBalanceFlag | bool | 財力-銀行餘額 | true | Item1_1_Flag；無資料為null |
| BankBalanceDes | Array<string> | 財力-銀行餘額說明 | ["國泰世華", "120"] | Item1_1_Des以;拆分；空值為[] |
| StockInventoryFlag | bool | 財力-集保庫存 | true | Item1_2_Flag；無資料為null |
| StockInventoryDes | Array<string> | 財力-集保庫存說明 | ["860"] | Item1_2_Des以;拆分；空值為[] |
| RealEstateFlag | bool | 財力-不動產 | false | Item1_3_Flag；無資料為null |
| RealEstateDes | Array<string> | 財力-不動產說明 | [] | Item1_3_Des以;拆分；空值為[] |
| OtherWealthFlag | bool | 財力-其他 | false | Item1_4_Flag；無資料為null |
| OtherWealthDes | Array<string> | 財力-其他說明 | [] | Item1_4_Des以;拆分；空值為[] |
| TotalWealth | number | 財力合計(萬元) | 980 | Item2_Des以;拆分第1段；無值或非數字為null |
| ProposedLendingAmt | number | 擬給予借貸款項額度(萬元) | 300 | Item2_Des以;拆分第2段；無值或非數字為null |

---
### 範例 JSON (Request)
```json
{
  "Header": {
    "Token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "UserId": "USER001",
    "SourceChannel": "WEB",
    "MessageID": "XXX-00000001"
  },
  "Body": {
    "SeqNo": "00012345",
    "BranchId": "888V",
    "Account": "9*****3"
  }
}
```

### 範例 JSON (Response - 成功)
```json
{
  "MsgId": "bd76582f1c9133693db8549553c69383",
  "Code": "000000",
  "Msg": "處理成功",
  "Timestamp": "20261117104730561",
  "TimeElapsed": "35",
  "Data": {
    "SeqNo": "00012345",
    "BranchId": "888V",
    "Account": "9*****3",
    "IDNO": "A*****789",
    "CustName": "林O哲",
    "Status": "3",
    "Kind": "1",
    "KindDes": "信用",
    "Type": "1",
    "TypeDes": "新開",
    "FinishDate": "20261105",
    "ApplyDate": "20261105",
    "SignDate": "20261105",
    "AllowDate": "20261105",
    "OpenDate": "20261105",
    "EffectDate": "20291104",
    "ContractOpenDate": "20261105",
    "Refund": "N",
    "AccountODate": "20180312",
    "StkOpenMonthFlag": "Y",
    "InvestExpDays": 3156,
    "InvestExpCode": "5",
    "TradeCount": 45,
    "TradeFreqCode": "2",
    "CType4Flag": "0",
    "CType4Des": "",
    "BreakFlag": "N",
    "B27QryDate": "20261028",
    "CreditOpenCnt": 1,
    "NlbOpenCnt": 0,
    "AdvOpenCnt": 0,
    "AnyOpenCnt": 0,
    "NlbAmount": 0,
    "B27AbnormalNote": null,
    "AmountNote": null,
    "TradeAmt": 1250.5,
    "InventoryAmt": 860,
    "ExpectAmt": 300,
    "Credit": 0,
    "MoneyLending": 100,
    "SecurityLending": 0,
    "OpenEnded": 50,
    "ApplyCredit": 300,
    "ApplyMoneyLending": 0,
    "ApplySecurityLending": 0,
    "ApplyOpenEnded": 0,
    "CreditR": 200,
    "MoneyLendingR": 0,
    "SecurityLendingR": 0,
    "OpenEndedR": 0,
    "TotalLimit": 450,
    "TotalLimitR": 650,
    "SalesName": "陳O宏",
    "SalesADate": "20261103",
    "DBossName": "王O明",
    "DBossADate": "20261103",
    "SupervisorName": "張O華",
    "SupervisorADate": "20261104",
    "DirectName": "",
    "DirectADate": "",
    "GMBossName": "",
    "GMBossADate": "",
    "BackOfficerName": "李O君",
    "BackOfficerADate": "20261105",
    "BEBossName": "黃O德",
    "BEBossADate": "20261105",
    "BankBalanceFlag": true,
    "BankBalanceDes": [
      "國泰世華",
      "120"
    ],
    "StockInventoryFlag": true,
    "StockInventoryDes": [
      "860"
    ],
    "RealEstateFlag": false,
    "RealEstateDes": [],
    "OtherWealthFlag": false,
    "OtherWealthDes": [],
    "TotalWealth": 980,
    "ProposedLendingAmt": 300
  }
}
```

### 範例 JSON (Response - 失敗)
```json
{
  "MsgId": "bd76582f1c9133693db8549553c69383",
  "Code": "999999",
  "Msg": "系統錯誤：資料庫連線失敗",
  "Timestamp": "20261117104730561",
  "TimeElapsed": "5",
  "Data": null
}
```
---

### 邏輯
```sql
--輸入參數
DECLARE @SeqNo    AS VARCHAR(8) = '00012345';
DECLARE @BranchId AS VARCHAR(4) = '888V';
DECLARE @Account  AS VARCHAR(7) = '9*****3';

--1. 主查詢（connstr）：查無資料回覆404001
--   AcctInfoByID 維持 inner join，帳號無 Type='1' 歸戶資料時視同查無資料
;WITH Main AS (
    SELECT O.SeqNo, O.BranchId, O.Account, O.IDNO, O.Status, O.Kind, O.Type,
           O.ApplyDate                                   AS OrigApplyDate,  --原始申請日yyyyMMdd，供5.使用
           CONVERT(VARCHAR(8), O.OpenDate, 112)          AS FinishDate,
           CONVERT(VARCHAR(8), O.ContractOpenDate, 112)  AS ContractOpenDate,
           ISNULL(O.ExpectAmt, 0)                        AS ExpectAmt,
           ISNULL(O.Refund, '')                          AS Refund,
           KindDes  = (SELECT RTRIM(Descript) FROM Content C WHERE RTRIM(ItemName) = 'CreditActKind'      AND C.No = O.Kind),
           TypeDes  = (SELECT RTRIM(Descript) FROM Content C WHERE RTRIM(ItemName) = 'ApplyCreditActType' AND C.No = O.Type),
           O.ApplySalesName,
           CustName = (SELECT RTRIM(CustName) FROM StkCusData S WITH (NOLOCK)
                        WHERE S.BranchId = O.BranchId AND S.Account = O.Account)
      FROM PC_OLAccount O WITH (NOLOCK)
     WHERE O.BranchId = @BranchId AND O.Account = @Account AND O.SeqNo = @SeqNo
)
SELECT M.*,
       CONVERT(VARCHAR(8), A.ODate, 112)            AS AccountODate,
       CONVERT(VARCHAR(8), R.ModifiedDate, 112)     AS RPAModifiedDate,
       DATEDIFF(d, A.ODate, R.ModifiedDate)         AS InvestExpDays,
       R.TradeAmt, R.InventoryAmt, R.TradeCount,
       ISNULL(R.Credit, 0)           AS Credit,
       ISNULL(R.MoneyLending, 0)     AS MoneyLending,
       ISNULL(R.SecurityLending, 0)  AS SecurityLending,
       ISNULL(R.OpenEnded, 0)        AS OpenEnded,
       ISNULL(R.CreditR, 0)          AS RPACreditR,
       ISNULL(R.MoneyLendingR, 0)    AS RPAMoneyLendingR,
       ISNULL(R.SecurityLendingR, 0) AS RPASecurityLendingR,
       ISNULL(R.OpenEndedR, 0)       AS RPAOpenEndedR,
       ISNULL(CONVERT(VARCHAR(1), C.CType_4_Flag), '') AS CType4Flag,
       ISNULL(RTRIM(C.CType_4_Des), '')                AS CType4Des,
       SalesName = CASE WHEN ISNULL(M.ApplySalesName, '') <> '' THEN M.ApplySalesName
                        ELSE dbo.fn_GetEmpName(C.SalesNo) END,
       ISNULL(CONVERT(VARCHAR(8), C.Sales_ADate, 112), '') AS SalesADate,
       dbo.fn_GetEmpName(C.DBossNo)      AS DBossName,      ISNULL(CONVERT(VARCHAR(8), C.DBoss_ADate, 112), '') AS DBossADate,
       dbo.fn_GetEmpName(C.SupervisorNo) AS SupervisorName, ISNULL(CONVERT(VARCHAR(8), C.Supervisor_ADate, 112), '') AS SupervisorADate,
       dbo.fn_GetEmpName(C.DirectNo)     AS DirectName,     ISNULL(CONVERT(VARCHAR(8), C.Direct_ADate, 112), '') AS DirectADate,
       dbo.fn_GetEmpName(C.GMBossNo)     AS GMBossName,     ISNULL(CONVERT(VARCHAR(8), C.GMBoss_ADate, 112), '') AS GMBossADate,
       BackOfficerName = ISNULL(dbo.fn_GetEmpName(C.BackOfficerNo),
                         (SELECT Descript FROM Content WHERE ItemName = 'SubstituteBK' AND No = M.BranchId
                             AND RIGHT(RTRIM(SubNo), 6) = C.BackOfficerNo)),
       ISNULL(CONVERT(VARCHAR(8), C.BackOfficer_ADate, 112), '') AS BackOfficerADate,
       BEBossName = ISNULL(dbo.fn_GetEmpName(C.BEBossNo),
                    (SELECT Descript FROM Content WHERE ItemName = 'Substitute' AND No = M.BranchId
                        AND RIGHT(RTRIM(SubNo), 6) = C.BEBossNo)),
       ISNULL(CONVERT(VARCHAR(8), C.BEBoss_ADate, 112), '') AS BEBossADate,
       --財力（新增）
       C.Item1_1_Flag AS BankBalanceFlag,    C.Item1_1_Des AS BankBalanceDes,
       C.Item1_2_Flag AS StockInventoryFlag, C.Item1_2_Des AS StockInventoryDes,
       C.Item1_3_Flag AS RealEstateFlag,     C.Item1_3_Des AS RealEstateDes,
       C.Item1_4_Flag AS OtherWealthFlag,    C.Item1_4_Des AS OtherWealthDes,
       C.Item2_Des                                        --財力合計;擬給予借貸款項額度
  FROM Main M
  LEFT JOIN PC_RPA R WITH (NOLOCK) ON R.SeqNo = M.SeqNo
 INNER JOIN AcctInfoByID A WITH (NOLOCK)
         ON A.BranchId = M.BranchId AND A.Account = M.Account AND A.Type = '1'
  LEFT JOIN PC_CreditInfoBySales C WITH (NOLOCK) ON C.OnlineSeqNo = M.SeqNo;

--2. 聯徵B27資料（CRMconnstr2）：違約記錄、查詢日期、已開戶數
--   @CatalogID='5'為線上授信類別
--   由程式以DataReader讀取結果並對應至Data欄位，讀取、判斷與對應方式見6.7
--   （SP回傳結構不固定，不在SQL內以INSERT...EXEC存入暫存表）
EXEC [dbo].[sp_GetB27Data] @SeqNo, '5';

--3. 聯徵異常說明、高風險說明（CRMconnstr2）：查無資料時兩欄為null
SELECT B27AbnormalNote, AmountNote
  FROM Workflow.dbo.CreditAccount WITH (NOLOCK)
 WHERE SeqNo = @SeqNo
   AND HighRiskAccountTag = 'Y';

--4. 關聯戶額度加總（CRMWorkflowconnstr）：結果供6.4計算CreditR、MoneyLendingR、SecurityLendingR、OpenEndedR
--   取最新一天的關聯戶資料；Type 1同戶籍地 2同手機號碼 4連帶保證人 5同Email 7同市話（排除3同買賣代理人、6其他關係人）
--   同一關聯戶因多種關係重複出現時，以DISTINCT(IDNO+四項額度)去重複，只算一筆
--   無關聯戶資料時四項皆為0
SELECT ISNULL(SUM(CASE WHEN Credit          <> 0 THEN Credit          END), 0) AS AffCreditR,
       ISNULL(SUM(CASE WHEN MoneyLending    >  0 THEN MoneyLending    END), 0) AS AffMoneyLendingR,
       ISNULL(SUM(CASE WHEN SecurityLending >  0 THEN SecurityLending END), 0) AS AffSecurityLendingR,
       ISNULL(SUM(CASE WHEN OpenEnded       >  0 THEN OpenEnded       END), 0) AS AffOpenEndedR
  FROM (SELECT DISTINCT IDNO, Credit, MoneyLending, OpenEnded, SecurityLending
          FROM AffiliatedAccountInfo WITH (NOLOCK)
         WHERE SeqNo = @SeqNo
           AND Date = (SELECT MAX(Date) FROM AffiliatedAccountInfo WHERE SeqNo = @SeqNo)
           AND Type IN ('1', '2', '4', '5', '7')) T;

--5. 契約開戶日 ContractOpenDate
--   Type=1(新開)、3(續約)：取1.主查詢的ContractOpenDate，不回寫
--   其他Type(如2調整額度)：先依5a判斷，不成立再查5b，皆無值則為空字串
--   其他Type且申請日(OrigApplyDate)為空時：不執行5a、5b、5c，ContractOpenDate為空字串（見6.0）
--   5a不成立、5b查到8碼日期時，執行5c回寫PC_OLAccount
DECLARE @Kind      AS VARCHAR(1) = '1';        --1.主查詢 Kind
DECLARE @ApplyDate AS VARCHAR(8) = '20261101'; --1.主查詢 OrigApplyDate

--5a. 不另查詢資料庫，以1.主查詢欄位判斷
--    （原程式以SeqNo重查PC_OLAccount同一筆申請，與1.主查詢為同一列，故直接沿用其欄位，結果相同）
--    條件：Status='3' 且 ISNULL(FinishDate,'19000101') <= OrigApplyDate 且 ContractOpenDate 不為空
--    成立 → ContractOpenDate 取1.主查詢的ContractOpenDate
--    不成立 → 查5b

--5b.（R6DBconnstr）帳號取前6碼(不含檢核碼)，依Kind查詢，結果轉yyyyMMdd
DECLARE @Acc AS VARCHAR(6) = LEFT(@Account, 6);
--Kind=1 信用
SELECT D_CD_OPEN_DATE AS OpenDate FROM CD_CLIENT WITH (NOLOCK)
 WHERE RTRIM(VC_BRANCH_CD) = @BranchId AND RTRIM(VC_CLIENT_ACC_NO) = @Acc AND D_CD_OPEN_DATE <= @ApplyDate;
--Kind=2 款項借貸（修正：篩選條件改為與取值欄位一致的 D_ODATE）
SELECT D_ODATE AS OpenDate FROM SB_CLIENT WITH (NOLOCK)
 WHERE RTRIM(VC_BRANCH_CD) = @BranchId AND RTRIM(VC_CLIENT_ACC_NO) = @Acc AND D_ODATE <= @ApplyDate;
--Kind=3 有價證券借貸
SELECT D_ODATE AS OpenDate FROM BP_CLIENT WITH (NOLOCK)
 WHERE RTRIM(VC_BRANCH_CD) = @BranchId AND RTRIM(VC_CLIENT_ACC_NO) = @Acc AND D_ODATE <= @ApplyDate;
--Kind=4 不限用途款項借貸
SELECT D_NODATE AS OpenDate FROM BP_CLIENT WITH (NOLOCK)
 WHERE RTRIM(VC_BRANCH_CD) = @BranchId AND RTRIM(VC_CLIENT_ACC_NO) = @Acc AND D_NODATE <= @ApplyDate;

--5c.（connstr）回寫契約開戶日：僅在5a不成立、5b查到8碼日期(yyyyMMdd)時執行
--    日期轉為yyyy-MM-dd寫入；回寫後ContractOpenDate回傳5b的值
--    回寫失敗(例外)回覆900000、Data為null，不回傳查詢結果
DECLARE @UserId           AS VARCHAR(30) = 'USER001';     --Header.UserId
DECLARE @ContractOpenDate AS VARCHAR(10) = '2023-05-02';  --5b結果轉yyyy-MM-dd
UPDATE PC_OLAccount
   SET ContractOpenDate = @ContractOpenDate,
       ModifiedUser     = @UserId,
       ModifiedDate     = GETDATE()
 WHERE BranchId = @BranchId AND Account = @Account AND SeqNo = @SeqNo;

--6. 程式計算規則
--   以下由API程式依1~5的查詢結果計算後放入Data，不在SQL內處理
--   API回傳判斷結果代碼與數值；報表的勾選框與文字由呼叫端組成（見報表欄位對應開發文件）
--   日期一律以yyyyMMdd字串回傳；日期加減以日曆計算（月底、閏年規則同.NET AddMonths/AddYears）
--
--6.0 申請日為空（1.主查詢 OrigApplyDate 為 null 或空字串）
--    僅影響5.契約開戶日：Type非1、3時不執行5a、5b、5c（不回寫），ContractOpenDate 為空字串
--    → 依6.5，調整額度的 AllowDate、OpenDate、EffectDate 隨之為空字串
--    其他查詢（2、3、4）與6.1~6.7的計算照常執行
--    （修正原程式：原程式將所有計算包在申請日判斷內，申請日為空時報表大多留白，
--      但聯合徵信原始代碼、作業完成日等原值仍會顯示；該判斷僅為拆解申請日的殘留防呆，
--      實際需要申請日的只有契約開戶日查詢）
--
--6.1 StkOpenMonthFlag 開設受託買賣帳戶滿三個月（原程式 ChkStkOpenMonth）
--    基準日 = AccountODate（證券帳戶開戶日）
--    比較日：Status='3'(已完成) → FinishDate（作業完成日）
--            其他狀態         → RPAModifiedDate（PC_RPA異動日）
--            比較日為空       → 系統日
--    比較日 >= 基準日 + 3個月 - 1日 → 'Y'，否則 'N'
--    例：AccountODate=20180312 → 門檻日20180611
--        比較日20180611 → 'Y'；比較日20180610 → 'N'
--
--6.2 InvestExpCode 投資經驗
--    InvestExpDays = DATEDIFF(day, AccountODate, RPAModifiedDate)（1.主查詢計算）
--    InvestExpDays 為 null（無PC_RPA資料或異動日為空）→ InvestExpCode 為 null
--    天數 >= 1825    → '5' 5年以上
--         730~1824   → '4' 2年至5年
--         365~729    → '3' 1年至2年
--         1~364      → '2' 1年以下
--         <= 0       → '1' 新開戶
--
--6.3 TradeFreqCode 交易頻率
--    TradeCount（PC_RPA交易次數）為 null 時視為0計算；TradeCount 欄位本身仍回 null
--    次數 >= 201     → '1' 每日
--         30~200     → '2' 每週
--         6~29       → '3' 每季
--         2~5        → '4' 半年
--         其他(<=1)  → '5' 一年以上
--
--6.4 額度（單位：萬元；各項來源為null時已於1.主查詢轉為0）
--  (1) 本次申請額度：依 Kind 將 ExpectAmt 放入對應欄位，其餘三欄為0
--      Kind=1 信用             → ApplyCredit（報表的融資額度、融券額度皆填此值）
--      Kind=2 款項借貸         → ApplyMoneyLending
--      Kind=3 有價證券借貸     → ApplySecurityLending
--      Kind=4 不限用途款項借貸 → ApplyOpenEnded
--  (2) TotalLimit 總授信額度-本人
--      本次申請的項目以 ExpectAmt 取代該項現有額度，再加上其他三項現有額度
--      Kind=1：ExpectAmt + MoneyLending + SecurityLending + OpenEnded
--      Kind=2：Credit + ExpectAmt + SecurityLending + OpenEnded
--      Kind=3：Credit + MoneyLending + ExpectAmt + OpenEnded
--      Kind=4：Credit + MoneyLending + SecurityLending + ExpectAmt
--  (3) 關聯戶額度 = 1.主查詢PC_RPA關聯戶額度 + 4.關聯戶額度加總
--      CreditR          = RPACreditR          + AffCreditR
--      MoneyLendingR    = RPAMoneyLendingR    + AffMoneyLendingR
--      SecurityLendingR = RPASecurityLendingR + AffSecurityLendingR
--      OpenEndedR       = RPAOpenEndedR       + AffOpenEndedR
--  (4) TotalLimitR 總授信額度-含關聯戶
--      TotalLimitR = TotalLimit + CreditR + MoneyLendingR + SecurityLendingR + OpenEndedR
--  例（範例Response）：Kind=1、ExpectAmt=300、MoneyLending=100、SecurityLending=0、OpenEnded=50
--      TotalLimit  = 300 + 100 + 0 + 50 = 450
--      CreditR=200、其餘關聯戶額度0 → TotalLimitR = 450 + 200 = 650
--
--6.5 日期（原程式 GatDateVal、GatTrustEndDay）
--    ApplyDate = SignDate = FinishDate（現行報表的申請日、簽約日皆填作業完成日）
--    FinishDate 為空（未完成）→ AllowDate、OpenDate、EffectDate 皆為空字串
--    FinishDate 有值時，依 Type、Kind 決定：
--    Type=1新開、3續約：
--      AllowDate = OpenDate = FinishDate
--      EffectDate = FinishDate + 3年 - 1日；Kind=3(有價證券借貸)為空字串
--    Type=2調整額度（ContractOpenDate 見5.）：
--      Kind=1、2、4：AllowDate = OpenDate = ContractOpenDate
--                    EffectDate = ContractOpenDate + 3年 - 1日
--      Kind=3      ：AllowDate = FinishDate；OpenDate = ContractOpenDate
--                    EffectDate = 空字串
--    其他 Type 或 Kind：三欄皆為空字串
--    ContractOpenDate 為空字串（5.皆無值）時，取用它的欄位皆為空字串
--    +3年-1日 例：20261105 → 20291104
--                 20240229 → 20270227（先加3年為20270228，再減1日）
--
--6.6 財力（PC_CreditInfoBySales 新增欄位）
--    BankBalanceFlag 等四個Flag：原值(bool)；無PC_CreditInfoBySales資料 → null
--    BankBalanceDes 等四個Des：以 ';' 拆成字串陣列，每段去除前後空白；null 或空字串 → []
--      例：'國泰世華; 120' → ["國泰世華", "120"]
--    Item2_Des 以 ';' 拆分：第1段 → TotalWealth，第2段 → ProposedLendingAmt
--      該段不存在、空白或非數字 → null
--      例：'980;300' → TotalWealth=980、ProposedLendingAmt=300
--          '980'     → TotalWealth=980、ProposedLendingAmt=null
--
--6.7 聯徵B27資料（邏輯2 sp_GetB27Data）讀取與對應
--    SP回傳結構（依原程式推論，SP本體未取得）：
--      A. 含BranchId、UID等欄位：已有B27結果
--      B. 僅Pk_BKNo、SendDate、IsSend、CatalogID、QryDate：已送查詢尚無結果
--    處理步驟（示意）：
--      var reader = ExecuteReader("EXEC [dbo].[sp_GetB27Data] @SeqNo, '5'");   --CRMconnstr2
--      if (!reader.Read())                    → 0筆，無B27資料：各欄位取下表「無資料」值
--      else if (!HasColumn(reader, "BREAK"))  → 結構B：回覆404002，Data=null，結束
--      else                                   → 結構A：依下表將reader欄位放入Data
--          if (reader.Read())                 → 結構A多於1筆：回覆900000，Data=null，結束（不擇一取用）
--    結構A欄位對應（SP欄位/推論型別 → Data欄位：轉換規則；無資料或null時的值）
--      BREAK       varchar  → BreakFlag     ：去除前後空白後原值；''
--      QryDate     datetime → B27QryDate    ：轉yyyyMMdd；''
--      CREDIT_OPEN int      → CreditOpenCnt ：原值；0
--      NLB_OPEN    int      → NlbOpenCnt    ：原值；0
--      ADV_OPEN    int      → AdvOpenCnt    ：原值；0
--      ANY_OPEN    int      → AnyOpenCnt    ：原值；0
--      NLB_AMOUNT  numeric  → NlbAmount     ：原值，證券借貸借券餘額(千元)；0
```

---

## 錯誤代碼說明
| 代碼 | 說明 | 處理方式 |
|------|--------|----------|
| 000000 | 處理成功 | - |
| 400001 | 無效的模型狀況 | 查無符合條件的資料 |
| 404001 | 未找到資料 | 請確認查詢條件是否正確（含帳號無歸戶資料） |
| 404002 | 聯徵結果尚未回覆 | 聯徵B27已送查詢但尚無結果，請稍後再查詢 |
| 900000 | SQL執行例外狀況 | SQL執行例外狀況（含回寫契約開戶日失敗、B27資料多於1筆） |
| 901000 | 參數驗證失敗 | 請檢查必填欄位是否完整 |
| 999999 | 不明或未定義的錯誤 | 發生未預期錯誤，請聯繫系統管理員 |

---

## 變更紀錄
| 日期 | 版本 | 變更內容 | 負責人 |
| --- | --- | --- | --- |
| 2026/11/17 | 1.0 | 初版 | 李桂昇 |
| 2026/11/18 | 1.1 | 新增契約開戶日由R6DB取得時回寫PC_OLAccount（邏輯5c）；回寫失敗回覆900000 | 李桂昇 |
| 2026/11/18 | 1.2 | 邏輯2補充sp_GetB27Data回傳結構（依原程式推論）與筆數規則；新增404002聯徵結果尚未回覆；NlbAmount說明改為證券借貸借券餘額(千元)；Data欄位與邏輯2補充B27欄位對應；B27讀取與對應移至邏輯6.7；邏輯4改為單一查詢（不使用暫存表），邏輯6.4與Data欄位明列四項關聯戶額度計算；邏輯5a改以主查詢欄位判斷，不另查詢；強化邏輯6程式計算規則說明；新增邏輯6.0申請日為空時僅略過契約開戶日查詢（修正原程式整張留白的瑕疵） | 李桂昇 |
